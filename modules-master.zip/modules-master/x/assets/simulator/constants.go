// Copyright [2021] - [2022], AssetMantle Pte. Ltd. and the code contributors
// SPDX-License-Identifier: Apache-2.0

package simulator

const OpWeightSubmitTextProposal = "op_weight_submit_text_proposal"
const DefaultWeightTextProposal = 1

const OpWeightMsg = "OpWeightMsg"
const DefaultWeightMsg = 1
